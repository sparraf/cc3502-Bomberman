# Este archivo almacena variables importantes sobre el escalamiento del juego, considerando
# que la pantalla de juego se puede dividir en "bloques" o "celdas"
ANCHO_CELDA = 40
ALTO_CELDA = 40

ANCHO_PANTALLA = 760
ALTO_PANTALLA = 600